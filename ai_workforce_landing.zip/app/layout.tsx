import "./globals.css";

export const metadata = {
  title: "All In Digital – AI Workforce Automation",
  description: "AI agents for speed-to-lead automation."
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
